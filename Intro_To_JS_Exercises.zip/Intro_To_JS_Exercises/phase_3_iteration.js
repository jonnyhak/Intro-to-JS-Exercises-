// Overview
// Let's do a few slightly more involved problems with arrays. These should be pretty familiar.

// Instructions
// Write the following functions:

// Array#bubbleSort - receives an array,
//  returns a sorted array by implementing bubble sort sorting algorithm
function bubbleSort(arr) {
    let sorted = false;

    while (sorted === false) {
        sorted = true;

        for (let j = 0; j < arr.length - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                sorted = false;
                let temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j+1] = temp;
            };
        };
    };

    return arr;
};

// console.log(bubbleSort([6,4,1,3,2]));



// String#substrings - receives a string, returns an array of all substrings

function substrings(string) {
    const newArr = [];
    let sub = "";

    for (let i = 0; i < string.length; i++) {
        sub = string[i];
        newArr.push(sub);
        for (let j = i + 1; j < string.length; j++) {
            sub += string[j];
            newArr.push(sub);
        }
    }

    return newArr; 
}


// console.log(substrings("bootcamp")) //[b, bo, boot...., o, oo, oot...., o, ot, otc, otca]