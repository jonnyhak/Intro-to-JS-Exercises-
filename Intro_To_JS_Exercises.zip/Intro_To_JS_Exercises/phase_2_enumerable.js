// Overview
// JavaScript enumerates over arrays differently than Ruby; rather than taking a block, they take a callback function, which is invoked for each element of the array.Take a look at the MDN Array Documentation if it is unclear how these methods are supposed to work.

//     Instructions
// Again, monkey - patch the following methods to the Array class using swell new language we've been learning.

// Array#myEach(callback) - receives a callback function and executes the callback for each element in the array
// Note that JavaScript's forEach function has no return value (returns undefined)

Array.prototype.myEach = function (callback) {
    
    for (let i = 0; i < this.length; i++) {
        callback(this[i])
    };
};

// console.log([1,2,3].myEach(ele => {console.log(ele)})); 




// console.log ([1,2,3].myEach(callback));


// Array#myMap(callback) - receives a callback function, returns a new array of the results of calling the callback function on each element of the array
// should use myEach and a closure
Array.prototype.myMap = function(callback) {
    const newArr = [];
    
    this.myEach(num => {
        newArr.push(callback(num));
    });
    
    return newArr;
};

const callback = function (ele) {
    return ele * 2;
};
// console.log([1,2,3].myMap(callback));





// Array#myReduce(callback[, initialValue]) - (like Ruby's Array#inject) receives a callback function, and optional initial value, returns an accumulator by applying the callback function to each element and the result of the last invocation of the callback (or initial value if supplied)

// initialValue is optional and should default to the first element of the array if not provided
// examples:

Array.prototype.myReduce = function (callback, initialValue) {
    let acc;
    let arr = this

    if (initialValue === undefined) {
        acc = this[0];
        arr = this.slice(1)
    } else {
        acc = initialValue;
    }

    arr.myEach (ele => {
        acc = callback(acc,ele)
    })
    
    // console.log(acc)
    return acc;
};

// // without initialValue
// const result = [1, 2, 3].myReduce(function (acc, el) {
//     return acc + el;
// }, 5); // => 6



// // with initialValue
const result = [1, 2, 3].myReduce(function (acc, el) {
    return acc + el;
}, 25); // => 31
// should also use myEach

// console.log(result) 


// NB[initialValue] is the conventional way for documentation to express that the args between[and] are optional inputs.Your function definition will not include these square brackets.



