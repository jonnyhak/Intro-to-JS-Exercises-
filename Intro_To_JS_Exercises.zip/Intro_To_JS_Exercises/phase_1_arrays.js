// Phase 1: Arrays
// Overview
// Let's take a little while to create a few (hopefully familiar) functions. These should give you some experience iterating over and mutating arrays.

// Instructions
// Monkey - patch the following methods to the Array class.Remember, we want to use prototype here.

// Array#uniq - returns a new array containing each individual element of the original array only once(creating all unique elements)
// the elements should be in the order in which they first appear in the original array
// should not mutate the original array
//     ([1, 2, 2, 3, 3, 3].uniq() => [1, 2, 3])

Array.prototype.uniq = function() { 
    const newArr = [];

    this.forEach(element => {
        if (!newArr.includes(element)) {
            newArr.push(element);
        }
    });

    return newArr;
  
};

// console.log([1, 2, 2, 3, 3, 3].uniq())
// console.log([1, 2, 2, 3, 3, 3, 5, 5, 24, 24].uniq())

// Array#twoSum - returns an array of position pairs where the elements sum to zero

Array.prototype.twoSum = function() {
    const newArr = [];
    // const arr = this;

    for (let i = 0; i < this.length - 1; i++) {
        for (let j = i; j < this.length; j++) {
            if (this[i] + this[j] === 0) {
                newArr.push([i,j]);
            };
        };
    };
    // this.forEach(ele, i => {
    //     this.forEach(ele1, j) => {
    //         if (this[i] + this[j] === 0) {
    //             newArr.push([i,j]);
    //         };
    //     };
    // };

    return newArr;
};

// console.log([1,3,4,-1,-4, 10].twoSum());

// Array#transpose - where we have a two - dimensional array representing a matrix.returns the transpose
// should not mutate the original array
// Recap
// That was super fun, right ?
// console.log("Hello") 

Array.prototype.transpose = function() {
    const newArr = [];
    const size = this[0].length;
    
    for (let i = 0; i < size; i++) {
        const subArr = [];
        for (let j = 0; j < this.length; j++) {
            subArr.push(this[j][i])
        };
        newArr.push(subArr);
    };

    return newArr;
};


// console.log([[1, 2, 3, 4], ['a', 'b', 'c', 'd'], [5,6,7,8,9,10]].transpose()); 