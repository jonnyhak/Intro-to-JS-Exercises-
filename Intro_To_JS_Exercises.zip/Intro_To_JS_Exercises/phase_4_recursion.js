// Instructions
// Write the following functions:

// range(start, end) - receives a start and end value, returns an array from start up to end
// (1,5) => [1,2,3,4,5] 
function range(start, end) {
    if (start === end) {
        return [start];
    };

    let arr = [start].concat(range(start + 1, end));
    return arr;
};

// console.log(range(1,5));

// sumRec(arr) - receives an array of numbers and recursively sums them

function sumRec(arr) {
    if (arr.length === 0) {
        return 0;
    }

    return arr[0] + sumRec(arr.slice(1))
}

// console.log(sumRec([24, 7, 22, 3]))



// exponent(base, exp) - receives a base and exponent, returns the base raise to the power of the exponent(base ^ exp)
//  2 ^ 4 = 2 * 2 * 2 * 2 => 16

function exponent(base, exp) {
    if (exp === 0) {
        return 1;
    };

    return base * exponent(base, exp-1);
};

// console.log(exponent(3,6));

// write two versions:# this is math, not Ruby methods.

// # version 1
// exp(b, 0) = 1
// exp(b, n) = b * exp(b, n - 1)

// # recursion 2
// exp(b, 0) = 1
// exp(b, 1) = b
// exp(b, n) = exp(b, n / 2) ** 2[for even n]
// exp(b, n) = b * (exp(b, (n - 1) / 2) ** 2)[for odd n]

// fibonacci(n) - receives an integer, n, and returns the first n Fibonacci numbers

function fibonacci(n) {
    if (n === 0) {
        return []
    }
    if (n === 1) {
        return [1]
    }
    if (n === 2) {
        return [1, 1]
    }

    let arr = [1, 1]

    return array.push(arr[-1] + arr[-2])
}

console.log(fibonacci(6)) // [0, 1, 1, 2, 3, 5]

// deepDup(arr) - deep dup of an Array!